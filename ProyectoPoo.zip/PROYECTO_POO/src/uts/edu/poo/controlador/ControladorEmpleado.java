
package uts.edu.poo.controlador;

import java.awt.event.*;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import uts.edu.poo.dao.EmpleadoDAO;
import uts.edu.poo.model.Empleado;
import uts.edu.poo.ui.InterfazEmpleado;

public class ControladorEmpleado implements ActionListener {

    private EmpleadoDAO dao = new EmpleadoDAO();
    private InterfazEmpleado vista;
    private DefaultTableModel modelo = new DefaultTableModel();

    public ControladorEmpleado(InterfazEmpleado vista) {
        this.vista = vista;
        this.vista.btnAgregar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnListar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnAgregar) agregar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnListar) {
            try {
                listar(vista.tblEmpleados);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(vista, "Error al listar empleados: " + ex.getMessage());
            }
        }
    }

    private void agregar() {
        try {
            String nombre = vista.txtNombre.getText();
            String cargo = vista.txtCargo.getText();

            if (nombre.isEmpty() || cargo.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debes llenar todos los campos obligatorios.");
                return;
            }

            Empleado e = new Empleado(0, nombre, cargo);
            dao.crear(e);
            JOptionPane.showMessageDialog(vista, "Empleado agregado correctamente.");
            listar(vista.tblEmpleados);
            limpiar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al agregar: " + ex.getMessage());
        }
    }

    private void actualizar() {
        int fila = vista.tblEmpleados.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un empleado de la tabla.");
            return;
        }
        try {
            int id = Integer.parseInt(vista.tblEmpleados.getValueAt(fila, 0).toString());
            String nombre = vista.txtNombre.getText();
            String cargo = vista.txtCargo.getText();

            Empleado e = new Empleado(id, nombre, cargo);
            dao.actualizar(e);
            JOptionPane.showMessageDialog(vista, "Empleado actualizado correctamente.");
            listar(vista.tblEmpleados);
            limpiar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage());
        }
    }

    private void eliminar() {
        int fila = vista.tblEmpleados.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un empleado para eliminar.");
            return;
        }
        int id = Integer.parseInt(vista.tblEmpleados.getValueAt(fila, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(vista, "¿Seguro que deseas eliminar este empleado?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                dao.eliminar(id);
                JOptionPane.showMessageDialog(vista, "Empleado eliminado correctamente.");
                listar(vista.tblEmpleados);
                limpiar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al eliminar: " + ex.getMessage());
            }
        }
    }

    private void listar(JTable tabla) throws SQLException {
        modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
        ArrayList<Empleado> lista = (ArrayList<Empleado>) dao.listar();
        for (Empleado e : lista) {
            modelo.addRow(new Object[]{e.getIdEmpleado(), e.getNombre(), e.getCargo()});
        }
        tabla.setModel(modelo);
    }

    private void limpiar() {
        vista.txtNombre.setText("");
        vista.txtCargo.setText("");
    }
}


