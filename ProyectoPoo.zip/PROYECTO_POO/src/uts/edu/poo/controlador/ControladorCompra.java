
package uts.edu.poo.controlador;

import java.awt.event.*;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import uts.edu.poo.dao.CompraDAO;
import uts.edu.poo.model.Compra;
import uts.edu.poo.ui.InterfazCompra;

public class ControladorCompra implements ActionListener {

    private CompraDAO dao = new CompraDAO();
    private InterfazCompra vista;
    private DefaultTableModel modelo = new DefaultTableModel();

    public ControladorCompra(InterfazCompra vista) {
        this.vista = vista;
        this.vista.btnAgregar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnListar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnAgregar) agregar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnListar) {
            try {
                listar(vista.tblCompras);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(vista, "Error al listar compras: " + ex.getMessage());
            }
        }
    }

    private void agregar() {
        try {
            Date fecha = Date.valueOf(vista.txtFecha.getText());
            int idCliente = Integer.parseInt(vista.txtIdCliente.getText());
            int idEmpleado = Integer.parseInt(vista.txtIdEmpleado.getText());

            Compra c = new Compra(0, fecha, idCliente, idEmpleado);
            dao.crear(c);
            JOptionPane.showMessageDialog(vista, "Compra agregada correctamente.");
            listar(vista.tblCompras);
            limpiar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al agregar compra: " + ex.getMessage());
        }
    }

    private void actualizar() {
        int fila = vista.tblCompras.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona una compra.");
            return;
        }
        try {
            int id = Integer.parseInt(vista.tblCompras.getValueAt(fila, 0).toString());
            Date fecha = Date.valueOf(vista.txtFecha.getText());
            int idCliente = Integer.parseInt(vista.txtIdCliente.getText());
            int idEmpleado = Integer.parseInt(vista.txtIdEmpleado.getText());

            Compra c = new Compra(id, fecha, idCliente, idEmpleado);
            dao.actualizar(c);
            JOptionPane.showMessageDialog(vista, "Compra actualizada correctamente.");
            listar(vista.tblCompras);
            limpiar();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage());
        }
    }

    private void eliminar() {
        int fila = vista.tblCompras.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona una compra para eliminar.");
            return;
        }
        int id = Integer.parseInt(vista.tblCompras.getValueAt(fila, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(vista, "¿Eliminar esta compra?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                dao.eliminar(id);
                JOptionPane.showMessageDialog(vista, "Compra eliminada correctamente.");
                listar(vista.tblCompras);
                limpiar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al eliminar: " + ex.getMessage());
            }
        }
    }

    private void listar(JTable tabla) throws SQLException {
        modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
        ArrayList<Compra> lista = (ArrayList<Compra>) dao.listar();
        for (Compra c : lista) {
            modelo.addRow(new Object[]{c.getIdCompra(), c.getFecha(), c.getIdCliente(), c.getIdEmpleado()});
        }
        tabla.setModel(modelo);
    }

    private void limpiar() {
        vista.txtFecha.setText("");
        vista.txtIdCliente.setText("");
        vista.txtIdEmpleado.setText("");
    }
}

