
package uts.edu.poo.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import uts.edu.poo.dao.ClienteDAO;
import uts.edu.poo.model.Cliente;
import uts.edu.poo.ui.InterfazCliente;

public class Controlador implements ActionListener {

    private Cliente c = new Cliente();
    private InterfazCliente vista;
    private ClienteDAO dao = new ClienteDAO();
    private DefaultTableModel modelo = new DefaultTableModel();

    public Controlador(InterfazCliente ic) {
        this.vista = ic;

        // Conectar los botones con el ActionListener
        this.vista.btnListar.addActionListener(this);
        this.vista.btnCrear.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

   @Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == vista.btnListar) {
        try {
            listar(vista.tblClientes);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al listar: " + ex.getMessage());
        }
    }

    if (e.getSource() == vista.btnCrear) {
        agregar();
    }

    if (e.getSource() == vista.btnActualizar) {
        actualizar();
    }

    if (e.getSource() == vista.btnEliminar) {
        eliminar();
    }
}


    private void listar(JTable tabla) throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);

        ArrayList<Cliente> lista = (ArrayList<Cliente>) dao.listar();

        Object[] fila = new Object[3];
        for (int i = 0; i < lista.size(); i++) {
            fila[0] = lista.get(i).getIdCliente();
            fila[1] = lista.get(i).getNombre();
            fila[2] = lista.get(i).getTelefono();
            modelo.addRow(fila);
        }

        tabla.setModel(modelo);
    }

    public void agregar() {
        try {
            String nombre = vista.txtNombre.getText();
            String telefono = vista.txtTelefono.getText();

            if (nombre.isEmpty() || telefono.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debes llenar todos los campos.");
                return;
            }

            Cliente cliente = new Cliente(0, nombre, telefono);
            dao.crear(cliente);

            JOptionPane.showMessageDialog(vista, "Cliente agregado correctamente.");

            listar(vista.tblClientes);
            limpiarCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al agregar cliente: " + e.getMessage());
        }
    }
    public void actualizar() {
    int fila = vista.tblClientes.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(vista, "Selecciona un cliente en la tabla para actualizar.");
        return;
    }

    try {
        int id = Integer.parseInt(vista.tblClientes.getValueAt(fila, 0).toString());
        String nombre = vista.txtNombre.getText();
        String telefono = vista.txtTelefono.getText();

        if (nombre.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debes llenar todos los campos.");
            return;
        }

        Cliente cliente = new Cliente(id, nombre, telefono);
        dao.actualizar(cliente);

        JOptionPane.showMessageDialog(vista, "Cliente actualizado correctamente.");
        listar(vista.tblClientes);
        limpiarCampos();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(vista, "Error al actualizar: " + e.getMessage());
    }
}
    public void eliminar() {
    int fila = vista.tblClientes.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(vista, "Selecciona un cliente en la tabla para eliminar.");
        return;
    }

    int confirmar = JOptionPane.showConfirmDialog(
        vista, 
        "¿Seguro que quieres eliminar este cliente?", 
        "Confirmar eliminación", 
        JOptionPane.YES_NO_OPTION
    );

    if (confirmar == JOptionPane.YES_OPTION) {
        try {
            int id = Integer.parseInt(vista.tblClientes.getValueAt(fila, 0).toString());
            dao.eliminar(id);

            JOptionPane.showMessageDialog(vista, "Cliente eliminado correctamente.");
            listar(vista.tblClientes);
            limpiarCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al eliminar: " + e.getMessage());
        }
    }
}


    private void limpiarCampos() {
        vista.txtNombre.setText("");
        vista.txtTelefono.setText("");
    }
}
