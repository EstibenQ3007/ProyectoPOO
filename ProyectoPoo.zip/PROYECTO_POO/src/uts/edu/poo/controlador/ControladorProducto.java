
package uts.edu.poo.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import uts.edu.poo.dao.ProductoDAO;
import uts.edu.poo.model.Producto;
import uts.edu.poo.ui.InterfazProducto;

public class ControladorProducto implements ActionListener {

    private Producto p = new Producto();
    private InterfazProducto vista;
    private ProductoDAO dao = new ProductoDAO();
    private DefaultTableModel modelo = new DefaultTableModel();

    public ControladorProducto(InterfazProducto ip) {
        this.vista = ip;

        this.vista.btnListar.addActionListener(this);
        this.vista.btnAgregar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnListar) {
            try {
                listar(vista.tblProductos);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al listar: " + ex.getMessage());
            }
        }

        if (e.getSource() == vista.btnAgregar) {
            agregar();
        }

        if (e.getSource() == vista.btnActualizar) {
            actualizar();
        }

        if (e.getSource() == vista.btnEliminar) {
            eliminar();
        }
    }

    private void listar(JTable tabla) throws SQLException {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);

        ArrayList<Producto> lista = (ArrayList<Producto>) dao.listar();

        Object[] fila = new Object[3];
        for (int i = 0; i < lista.size(); i++) {
            fila[0] = lista.get(i).getIdProducto();
            fila[1] = lista.get(i).getNombreProd();
            fila[2] = lista.get(i).getPrecio();
            modelo.addRow(fila);
        }

        tabla.setModel(modelo);
    }

    public void agregar() {
        try {
            String nombre = vista.txtNombre.getText();
            int precio = Integer.parseInt(vista.txtPrecio.getText());

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debes llenar todos los campos.");
                return;
            }

            Producto producto = new Producto(0, nombre, precio);
            dao.agregar(producto);

            JOptionPane.showMessageDialog(vista, "Producto agregado correctamente.");
            listar(vista.tblProductos);
            limpiarCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al agregar producto: " + e.getMessage());
        }
    }

    public void actualizar() {
        int fila = vista.tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un producto en la tabla para actualizar.");
            return;
        }

        try {
            int id = Integer.parseInt(vista.tblProductos.getValueAt(fila, 0).toString());
            String nombre = vista.txtNombre.getText();
            int precio = Integer.parseInt(vista.txtPrecio.getText());

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debes llenar todos los campos.");
                return;
            }

            Producto producto = new Producto(id, nombre, precio);
            dao.actualizar(producto);

            JOptionPane.showMessageDialog(vista, "Producto actualizado correctamente.");
            listar(vista.tblProductos);
            limpiarCampos();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar: " + e.getMessage());
        }
    }

    public void eliminar() {
        int fila = vista.tblProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un producto en la tabla para eliminar.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(
            vista, 
            "¿Seguro que quieres eliminar este producto?", 
            "Confirmar eliminación", 
            JOptionPane.YES_NO_OPTION
        );

        if (confirmar == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(vista.tblProductos.getValueAt(fila, 0).toString());
                dao.eliminar(id);

                JOptionPane.showMessageDialog(vista, "Producto eliminado correctamente.");
                listar(vista.tblProductos);
                limpiarCampos();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(vista, "Error al eliminar: " + e.getMessage());
            }
        }
    }

    private void limpiarCampos() {
        vista.txtNombre.setText("");
        vista.txtPrecio.setText("");
    }
}


   

