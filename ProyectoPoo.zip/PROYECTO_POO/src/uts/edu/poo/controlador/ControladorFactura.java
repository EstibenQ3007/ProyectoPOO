package uts.edu.poo.controlador;

import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import uts.edu.poo.dao.DetalleCompraDAO;
import uts.edu.poo.model.DetalleCompra;
import uts.edu.poo.ui.InterfazFactura;

public class ControladorFactura implements ActionListener {

    private DetalleCompraDAO dao = new DetalleCompraDAO();
    private InterfazFactura vista;
    private DefaultTableModel modeloTabla;

    public ControladorFactura(InterfazFactura vista) {
        this.vista = vista;
        System.out.println("[DEBUG] Controlador inicializado");
        
        // Agregar listeners a los botones
        this.vista.btnListar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        
        System.out.println("[DEBUG] Listeners agregados a los botones");
        
        // Configurar la tabla
        configurarTabla();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("[DEBUG] Evento detectado: " + e.getSource());
        
        if (e.getSource() == vista.btnListar) {
            System.out.println("[DEBUG] Boton LISTAR presionado");
            listarDetallesCompra();
        }
        if (e.getSource() == vista.btnLimpiar) {
            System.out.println("[DEBUG] Boton LIMPIAR presionado");
            limpiar();
        }
    }

    private void configurarTabla() {
        vista.tblProductos.setDefaultEditor(Object.class, null);
        System.out.println("[DEBUG] Tabla configurada como no editable");
    }

    private void listarDetallesCompra() {
        System.out.println("[DEBUG] Iniciando listarDetallesCompra()");
        
        // Validar que el campo ID no esté vacío
        if (vista.txtIdFactura.getText().trim().isEmpty()) {
            System.out.println("[WARN] Campo ID vacio");
            JOptionPane.showMessageDialog(vista, 
                "Por favor ingresa el ID de la compra.", 
                "Campo vacio", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int idCompra = Integer.parseInt(vista.txtIdFactura.getText().trim());
            System.out.println("[DEBUG] Buscando compra con ID: " + idCompra);
            
            // Verificar si existe la compra
            if (!dao.existeCompra(idCompra)) {
                System.out.println("[ERROR] Compra no encontrada: " + idCompra);
                JOptionPane.showMessageDialog(vista, 
                    "No existe una compra con el ID: " + idCompra, 
                    "Compra no encontrada", 
                    JOptionPane.ERROR_MESSAGE);
                limpiar();
                return;
            }
            
            System.out.println("[DEBUG] Compra encontrada, obteniendo detalles...");
            
            // Obtener los detalles de la compra
            List<DetalleCompra> detalles = dao.listarPorCompra(idCompra);
            System.out.println("[DEBUG] Detalles obtenidos: " + detalles.size() + " productos");
            
            if (detalles.isEmpty()) {
                System.out.println("[WARN] Sin productos en esta compra");
                JOptionPane.showMessageDialog(vista, 
                    "Esta compra no tiene productos asociados.", 
                    "Sin detalles", 
                    JOptionPane.INFORMATION_MESSAGE);
                limpiar();
                return;
            }
            
            // Llenar la tabla
            modeloTabla = (DefaultTableModel) vista.tblProductos.getModel();
            modeloTabla.setRowCount(0);
            
            double subtotalTotal = 0.0;
            
            for (DetalleCompra dc : detalles) {
                System.out.println("[DEBUG] Agregando: " + dc.getNombreProducto() + 
                                 " | Cantidad: " + dc.getCantidad() + 
                                 " | Subtotal: " + dc.getSubtotal());
                
                modeloTabla.addRow(new Object[]{
                    dc.getNombreProducto(),
                    String.format("%.2f", dc.getPrecioUnitario()),
                    dc.getCantidad(),
                    String.format("%.2f", dc.getSubtotal())
                });
                subtotalTotal += dc.getSubtotal();
            }
            
            System.out.println("[DEBUG] Subtotal calculado: " + subtotalTotal);
            
            // Actualizar el subtotal
            vista.txtSubtotal.setText(String.format("%.2f", subtotalTotal));
            
            // Obtener y mostrar el empleado que atendió
            String empleado = dao.obtenerEmpleadoPorCompra(idCompra);
            System.out.println("[DEBUG] Empleado: " + empleado);
            vista.txtEmpleadoAtiende.setText(empleado);
            
            JOptionPane.showMessageDialog(vista, 
                "Factura cargada correctamente.\n" + 
                "Productos: " + detalles.size() + 
                "\nTotal: $" + String.format("%.2f", subtotalTotal), 
                "Exito", 
                JOptionPane.INFORMATION_MESSAGE);
            
            System.out.println("[DEBUG] Proceso completado exitosamente");
            
        } catch (NumberFormatException ex) {
            System.out.println("[ERROR] Error de formato: " + ex.getMessage());
            JOptionPane.showMessageDialog(vista, 
                "El ID de la compra debe ser un numero valido.", 
                "Error de formato", 
                JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            System.out.println("[ERROR] Error de BD: " + ex.getMessage());
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista, 
                "Error al consultar la base de datos:\n" + ex.getMessage(), 
                "Error de BD", 
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            System.out.println("[ERROR] Error inesperado: " + ex.getMessage());
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista, 
                "Error inesperado:\n" + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiar() {
        System.out.println("[DEBUG] Limpiando campos...");
        vista.txtIdFactura.setText("");
        vista.txtSubtotal.setText("");
        vista.txtEmpleadoAtiende.setText("");
        
        modeloTabla = (DefaultTableModel) vista.tblProductos.getModel();
        modeloTabla.setRowCount(0);
        
        System.out.println("[DEBUG] Campos limpiados");
    }
}