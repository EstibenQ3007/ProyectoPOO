
package uts.edu.poo.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    //solo cambiar /supermercado si le pusistes otro nombre a la base de
    //datos dento de pgAdmin 4
    //recomendacion colocarle ese nombre 
    private static final String URL = "jdbc:postgresql://localhost:5432/Supermercado";
    //no se toca nada en esta linea
    private static final String USER = "postgres";
    //su contraseña de pgAdmin
    private static final String PASSWORD = "123";
    //ir al paquete uts.edu.poo.PruebaConexion para ejecutar y 
    //hacer comprobacion de conexion 
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
