
package uts.edu.poo.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import uts.edu.poo.model.Compra;

public class CompraDAO {

    public void crear(Compra c) throws SQLException {
        String sql = "INSERT INTO compra (fecha, id_cliente, id_empleado) VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, c.getFecha());
            ps.setInt(2, c.getIdCliente());
            ps.setInt(3, c.getIdEmpleado());
            ps.executeUpdate();
        }
    }

    public List<Compra> listar() throws SQLException {
        List<Compra> lista = new ArrayList<>();
        String sql = "SELECT * FROM compra ORDER BY id_compra ASC";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Compra c = new Compra(
                    rs.getInt("id_compra"),
                    rs.getDate("fecha"),
                    rs.getInt("id_cliente"),
                    rs.getInt("id_empleado")
                );
                lista.add(c);
            }
        }
        return lista;
    }

    public void actualizar(Compra c) throws SQLException {
        String sql = "UPDATE compra SET fecha=?, id_cliente=?, id_empleado=? WHERE id_compra=?";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, c.getFecha());
            ps.setInt(2, c.getIdCliente());
            ps.setInt(3, c.getIdEmpleado());
            ps.setInt(4, c.getIdCompra());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM compra WHERE id_compra=?";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
