package uts.edu.poo.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import uts.edu.poo.model.DetalleCompra;

public class DetalleCompraDAO {
    
    public List<DetalleCompra> listarPorCompra(int idCompra) throws SQLException {
        List<DetalleCompra> lista = new ArrayList<>();
        String sql = "SELECT dc.id_detalle, dc.cantidad, dc.precio_unitario, dc.subtotal, " +
                     "dc.id_compra, dc.id_producto, p.nombre_prod " +
                     "FROM Detalle_Compra dc " +
                     "INNER JOIN Producto p ON dc.id_producto = p.id_producto " +
                     "WHERE dc.id_compra = ? " +
                     "ORDER BY dc.id_detalle ASC";
        
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCompra);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DetalleCompra dc = new DetalleCompra(
                        rs.getInt("id_detalle"),
                        rs.getInt("cantidad"),
                        rs.getDouble("precio_unitario"),
                        rs.getDouble("subtotal"),
                        rs.getInt("id_compra"),
                        rs.getInt("id_producto"),
                        rs.getString("nombre_prod")
                    );
                    lista.add(dc);
                }
            }
        }
        return lista;
    }
    
   //Calcula el total de la compra
    public double calcularTotalCompra(int idCompra) throws SQLException {
        String sql = "SELECT SUM(subtotal) as total FROM Detalle_Compra WHERE id_compra = ?";
        double total = 0.0;
        
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCompra);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getDouble("total");
                }
            }
        }
        return total;
    }
    
  //Nombre del empleado que atiende la compra
    public String obtenerEmpleadoPorCompra(int idCompra) throws SQLException {
        String sql = "SELECT e.nombre_emp " +
                     "FROM Compra c " +
                     "INNER JOIN Empleado e ON c.id_empleado = e.id_empleado " +
                     "WHERE c.id_compra = ?";
        String nombreEmpleado = "";
        
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCompra);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    nombreEmpleado = rs.getString("nombre_emp");
                }
            }
        }
        return nombreEmpleado;
    }
    
  //Existe compra con id dado?
    public boolean existeCompra(int idCompra) throws SQLException {
        String sql = "SELECT COUNT(*) as total FROM Compra WHERE id_compra = ?";
        
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCompra);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }
        }
        return false;
    }
}