
package uts.edu.poo.dao;

import uts.edu.poo.model.Producto;
import java.sql.*;
import java.util.*;

public class ProductoDAO {
    public void agregar(Producto p) throws SQLException {
        String sql = "INSERT INTO producto (nombre_prod, precio) VALUES (?, ?)";
        try (Connection con = ConexionBD.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombreProd());
            ps.setInt(2, p.getPrecio());
            ps.executeUpdate();
        }
    }

    public List<Producto> listar() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto ORDER BY id_producto";
        try (Connection con = ConexionBD.getConnection(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Producto(
                    rs.getInt("id_producto"),
                    rs.getString("nombre_prod"),
                    rs.getInt("precio")
                ));
            }
        }
        return lista;
    }

    public Producto buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM producto WHERE id_producto = ?";
        try (Connection con = ConexionBD.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Producto(
                        rs.getInt("id_producto"),
                        rs.getString("nombre_prod"),
                        rs.getInt("precio")
                    );
                }
            }
        }
        return null;
    }

    public void actualizar(Producto p) throws SQLException {
        String sql = "UPDATE producto SET nombre_prod=?, precio=? WHERE id_producto=?";
        try (Connection con = ConexionBD.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombreProd());
            ps.setInt(2, p.getPrecio());
            ps.setInt(3, p.getIdProducto());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM producto WHERE id_producto=?";
        try (Connection con = ConexionBD.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
