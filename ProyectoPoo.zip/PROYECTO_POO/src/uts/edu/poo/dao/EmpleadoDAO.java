
package uts.edu.poo.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import uts.edu.poo.model.Empleado;

public class EmpleadoDAO {

    public void crear(Empleado e) throws SQLException {
        String sql = "INSERT INTO empleado (nombre_emp, puesto) VALUES (?, ?)";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getCargo());
            ps.executeUpdate();
        }
    }

    public List<Empleado> listar() throws SQLException {
        List<Empleado> lista = new ArrayList<>();
        String sql = "SELECT * FROM empleado ORDER BY id_empleado ASC";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Empleado e = new Empleado(
                    rs.getInt("id_empleado"),
                    rs.getString("nombre_emp"),
                    rs.getString("puesto")
                );
                lista.add(e);
            }
        }
        return lista;
    }

    public void actualizar(Empleado e) throws SQLException {
        String sql = "UPDATE empleado SET nombre_emp=?, puesto=? WHERE id_empleado=?";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getNombre());
            ps.setString(2, e.getCargo());
            ps.setInt(3, e.getIdEmpleado());
            ps.executeUpdate();
        }
    }

    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM empleado WHERE id_empleado=?";
        try (Connection con = ConexionBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

