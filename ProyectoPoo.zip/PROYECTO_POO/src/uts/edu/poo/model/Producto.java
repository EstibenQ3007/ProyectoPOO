
package uts.edu.poo.model;

public class Producto {
    private int idProducto;
    private String NombreProd;
    private int Precio;

    public Producto() {
    }

    public Producto(int idProducto, String NombreProd, int Precio) {
        this.idProducto = idProducto;
        this.NombreProd = NombreProd;
        this.Precio = Precio;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProd() {
        return NombreProd;
    }

    public void setNombreProd(String NombreProd) {
        this.NombreProd = NombreProd;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }
    
    
}
