
package uts.edu.poo.model;

import java.sql.Date;

public class Compra {
    private int idCompra;
    private Date fecha;
    private int idCliente;
    private int idEmpleado;

    public Compra() {
    }

    public Compra(int idCompra, Date fecha, int idCliente, int idEmpleado) {
        this.idCompra = idCompra;
        this.fecha = fecha;
        this.idCliente = idCliente;
        this.idEmpleado = idEmpleado;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
}

