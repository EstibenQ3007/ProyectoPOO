package uts.edu.poo.model;

public class DetalleCompra {
    private int idDetalle;
    private int cantidad;
    private double precioUnitario;
    private double subtotal;
    private int idCompra;
    private int idProducto;
    private String nombreProducto; // Para mostrar en la tabla

    // Constructor vacío
    public DetalleCompra() {
    }

    // Constructor completo
    public DetalleCompra(int idDetalle, int cantidad, double precioUnitario, double subtotal, 
                        int idCompra, int idProducto, String nombreProducto) {
        this.idDetalle = idDetalle;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.subtotal = subtotal;
        this.idCompra = idCompra;
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
    }

    // Getters y Setters
    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }
}