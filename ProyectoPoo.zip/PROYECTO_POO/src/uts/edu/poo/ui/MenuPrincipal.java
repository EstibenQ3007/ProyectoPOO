/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package uts.edu.poo.ui;

import javax.swing.JOptionPane;
import uts.edu.poo.controlador.Controlador;
import uts.edu.poo.controlador.ControladorCompra;
import uts.edu.poo.controlador.ControladorEmpleado;
import uts.edu.poo.controlador.ControladorFactura;
import uts.edu.poo.controlador.ControladorProducto;
/**
 *
 * @author efray
 */
public class MenuPrincipal extends javax.swing.JFrame {

  
    public MenuPrincipal() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuGestion = new javax.swing.JMenu();
        menuClientes = new javax.swing.JMenuItem();
        menuProductos = new javax.swing.JMenuItem();
        menuEmpleados = new javax.swing.JMenuItem();
        menuCompras = new javax.swing.JMenuItem();
        menuFactura = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        acercaInformacion = new javax.swing.JMenuItem();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 20)); // NOI18N
        jLabel1.setText("Bienvenido al Sistema de Gestión del Supermercado ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(273, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 400));

        menuGestion.setBorder(null);
        menuGestion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/menu.png"))); // NOI18N
        menuGestion.setText("MENU");
        menuGestion.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        menuClientes.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        menuClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/personas.png"))); // NOI18N
        menuClientes.setText("CLIENTES");
        menuClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuClientesActionPerformed(evt);
            }
        });
        menuGestion.add(menuClientes);

        menuProductos.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        menuProductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/paquete-o-empaquetar.png"))); // NOI18N
        menuProductos.setText("PRODUCTOS");
        menuProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuProductosActionPerformed(evt);
            }
        });
        menuGestion.add(menuProductos);

        menuEmpleados.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        menuEmpleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/empresario.png"))); // NOI18N
        menuEmpleados.setText("EMPLEADOS");
        menuEmpleados.setBorder(null);
        menuEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEmpleadosActionPerformed(evt);
            }
        });
        menuGestion.add(menuEmpleados);

        menuCompras.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        menuCompras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/carrito-de-compras.png"))); // NOI18N
        menuCompras.setText("COMPRAS");
        menuCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuComprasActionPerformed(evt);
            }
        });
        menuGestion.add(menuCompras);

        menuFactura.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/FACTURA.png"))); // NOI18N
        menuFactura.setText("FACTURA");
        menuFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuFacturaActionPerformed(evt);
            }
        });
        menuGestion.add(menuFactura);

        menuSalir.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        menuSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/SALIR.png"))); // NOI18N
        menuSalir.setText("SALIR");
        menuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSalirActionPerformed(evt);
            }
        });
        menuGestion.add(menuSalir);

        jMenuBar1.add(menuGestion);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/acerca-de- proyecto.png"))); // NOI18N
        jMenu2.setText("ACERCA DE");
        jMenu2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        acercaInformacion.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        acercaInformacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/uts/edu/poo/iconos/acerca-de.png"))); // NOI18N
        acercaInformacion.setText("NOSOTROS");
        acercaInformacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acercaInformacionActionPerformed(evt);
            }
        });
        jMenu2.add(acercaInformacion);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuClientesActionPerformed
        InterfazCliente vista = new InterfazCliente();
        Controlador control = new Controlador(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_menuClientesActionPerformed

    private void menuProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuProductosActionPerformed
        InterfazProducto vista = new InterfazProducto();
        ControladorProducto control = new ControladorProducto(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_menuProductosActionPerformed

    private void menuEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEmpleadosActionPerformed
        InterfazEmpleado vista = new InterfazEmpleado();
        ControladorEmpleado control = new ControladorEmpleado(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_menuEmpleadosActionPerformed

    private void menuComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuComprasActionPerformed
        InterfazCompra vista = new InterfazCompra();
        ControladorCompra control = new ControladorCompra(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_menuComprasActionPerformed

    private void acercaInformacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acercaInformacionActionPerformed
        JOptionPane.showMessageDialog(this, 
        "Sistema de Gestión de Supermercado\n"
      + "Versión 1.0\n\n"
      + "Desarrollado por:\n"
      + "• Harvic Quintero Caceres\n"
      + "• Estiben Quiñonez Arango\n"
      + "• Carlos Esteban Perez Esparza\n"
      + "Institución: Unidades Tecnológicas de Santander (UTS)\n"
      + "Materia: Programación Orientada a Objetos",
      "Acerca de", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_acercaInformacionActionPerformed

    private void menuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSalirActionPerformed
         int opcion = JOptionPane.showConfirmDialog(
        this,
        "¿Seguro que deseas salir del sistema?",
        "Confirmar salida",
        JOptionPane.YES_NO_OPTION
    );
    
    if (opcion == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
    }//GEN-LAST:event_menuSalirActionPerformed

    private void menuFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuFacturaActionPerformed
        // TODO add your handling code here:
        InterfazFactura vista = new InterfazFactura();
        ControladorFactura control = new ControladorFactura(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_menuFacturaActionPerformed

   
     public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem acercaInformacion;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem menuClientes;
    private javax.swing.JMenuItem menuCompras;
    private javax.swing.JMenuItem menuEmpleados;
    private javax.swing.JMenuItem menuFactura;
    private javax.swing.JMenu menuGestion;
    private javax.swing.JMenuItem menuProductos;
    private javax.swing.JMenuItem menuSalir;
    // End of variables declaration//GEN-END:variables
}
